/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automation;

import java.util.Scanner;
import java.util.*;

public class Automation {

    public static void main(String[] args) {
        
        // initialize variables
        Stack stack = new Stack();
        Stack temp = new Stack();
        Scanner s = new Scanner(System.in);
        
        int flag = 0;
        String initial = "";
        int check = 0;
        
        // main statement
        while (true) {
            try {
                // first statement 0 and only $
                if(stack.size() == 0) {
                    System.out.print("Current status " + String.valueOf(flag) +  ":$, Enter input: ");
                }
                // after first statement
                else {
                    String s_temp = "";
                    
                    // get all elements from stack
                    for(int i = 0; i < stack.size(); i++) {
                        s_temp += stack.get(stack.size() - i - 1);
                    }
                    System.out.print("Current status " + String.valueOf(flag) +  ":" + s_temp + "$, Enter input: ");
                }
                
                // get input data from console by user
                String input = s.nextLine();
                
                // if input data is ".", break while statement
                if(input.equals(".")) {
                    // if size of stack is 0
                    if(stack.size() == 0) {
                        // if not stack error, string accepted
                        if(check == 0) {
                            System.out.println("String accepted.");
                        }
                        // if stack error, string rejected
                        else {
                            System.out.println("String rejected.");
                        }
                    }
                    // else, String reject
                    else {
                        System.out.println("String rejected.");
                    }
                    break;
                }

                // if first statement, push A
                if(flag == 0) {
                    flag = 1;
                    stack.push("A");
                    initial = input;
                }
                // if after first statement
                else {
                    // if top of stack equals input data
                    if(temp.peek().equals(input)) {
                        // if input data not equals initial data, push a
                        if(input.equals(initial)) {
                            stack.push("a");
                        }
                        // else, pop
                        else {
                            stack.pop();
                        }
                    }
                    // else, pop stack 
                    else {
                        flag++;
                        stack.pop();
                    }
                }

                temp.push(input);
            }
            // stack error check
            catch(Exception e) {
                System.out.println("Stack Error");
                check = 1;
            }
        }
    }
    
}
